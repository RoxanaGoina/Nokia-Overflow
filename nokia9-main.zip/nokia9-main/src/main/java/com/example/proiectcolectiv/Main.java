package com.example.proiectcolectiv;

import javax.xml.crypto.Data;

public class Main {
    public static void main( String []args){
       // DataBase.createTableUser("USER");
    }
}
