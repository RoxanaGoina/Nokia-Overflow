package com.example.proiectcolectiv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProiectColectivApplicationTests {

    @Test
    void contextLoads() {
    }

}
